# Results index

Start with the [project check-in and figures](../docs/PROJECT_CHECK_IN_2026-11-02.md).
Use the [data and status map](../docs/DATA_AND_STATUS_MAP_2026-11-02.md) for storage,
backup limits, and the latest observed training completion.

| Workstream | Readable evidence | Compact data | Interpretation |
|---|---|---|---|
| EEG decoder and command replay | [Check-in](../docs/PROJECT_CHECK_IN_2026-11-02.md) | [Plot data and input hashes](project_checkin_plot_data_2026-11-02.json), [figures](figures/) | Offline calibrated EEG and request traces; no learned EEG-to-robot result |
| Scripted EEG comparison | [Completion protocol](../docs/completion_protocol_2026-11-02.md) | Earlier raw artifacts are indexed by the [release handoff](../docs/ARTIFACT_HANDOFF.md) | Corrected matched physical batch remains incomplete; historical 24-s comparison is invalid |
| Project Approach PPO | [Run handoff](../docs/BREV_HANDOFF_2026-11-02.md) | [Summary](ppo_approach_handoff_2026-11-02.json), [episodes](ppo_approach_episode_results_2026-11-02.csv), [hashes](ppo_approach_sha256_2026-11-02.json) | 100 updates, 204,800 transitions, 0/5 measured table lifts; recorder execution-path caveat |
| NVIDIA candidate: valid screen | [Reset diagnostic](../docs/NVIDIA_CANDIDATE_RESET_DIAGNOSTIC_2026-11-02.md) | [Fresh-process results](nvidia_candidate_2026-11-02/reset_diagnostic.json) | 1/5 valid sampled lifts; high forces/corrections; early terminations retained |
| NVIDIA candidate: superseded screen | [Correction](../docs/NVIDIA_CANDIDATE_INTEGRATION_2026-11-02.md) | [Reset audit](nvidia_candidate_2026-11-02/reset_audit.json) | `episodes.csv`, `evaluation_summary.json`, and `serialized_rescore.json` describe the original screen with four invalid starts. Do not treat them as a valid 1/5 estimate |
| Candidate recorder guards | [Guard changes](../docs/NVIDIA_CANDIDATE_GUARDS_2026-11-02.md) | [Offline checks](nvidia_candidate_2026-11-02/guard_review.json) | CPU tests and saved-trace rescoring only; no new physical run |
| Near-table learning | [Curriculum and reset gate](../docs/NEAR_TABLE_CURRICULUM_2026-11-02.md) | [Reset screen](near_table_reset_screen_2026-11-02.json), [artifact inventory](artifact_inventory_2026-11-02.json) | Training now observed complete: 250 updates / 2,048,000 transitions, exit 0, model_249.pt. Physical pickup screen not verified here |
| Other policy reuse | [Panda PPO review](../docs/PANDA_PPO_REUSE_REVIEW_2026-11-02.md) | [Candidate manifest](policy_candidate_manifest_2026-11-02.json) | Source/compatibility review; not a measured pickup result |

The [artifact inventory](artifact_inventory_2026-11-02.json) lists 36 local run
folders, their sizes, available exit records, and hashes for 193 key files.
It is a timestamped local inventory, not a backup or a performance scorecard.
Raw checkpoints and telemetry stay in ignored outputs; compact records belong here.
Do not aggregate screens with different resets, horizons, controllers, or validity.
